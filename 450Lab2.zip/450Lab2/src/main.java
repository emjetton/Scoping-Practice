public class main {
    public static void main (String [] args)
    {
        int num = 1;

        for(int i = 0; i<5; i++)
        {
             num = num+i;
        }

        System.out.println(num);
    }

}
